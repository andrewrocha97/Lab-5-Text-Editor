﻿'Name:          Andrew Rocha
'ID:            100590342
'Date Created:  April 4th, 2019
'Purpose:       Lab 5 - Text Editor
'Description:   A client has contracted your company to create a text editor. You will be creating a Windows
'               Forms application that will need To be able To open, close, edit, save, save As, And create
'               New files (.txt). 
'

Option Strict On
Imports System.IO
Public Class frmTextEditor
    Private Sub mnuNew_Click(sender As Object, e As EventArgs) Handles mnuNew.Click

        ' Clears text editor '
        txtUserInput.Clear()

    End Sub

    Private Sub mnuOpen_Click(sender As Object, e As EventArgs) Handles mnuOpen.Click

        Dim openFile As New OpenFileDialog ' Open file Dialog box ' 
        Dim pathOfFile As String = String.Empty ' File path for user created file '

        ' If dialog box opens, user will continue to open a file '
        If openFile.ShowDialog() = DialogResult.OK Then

            pathOfFile = openFile.FileName

            Dim fileReader As New StreamReader(pathOfFile)
            txtUserInput.Text = fileReader.ReadToEnd()
            fileReader.Close()

        End If

    End Sub
    Private Sub Save(pathFileSave As String)

        Dim fileStream As New FileStream(pathFileSave, FileMode.Create, FileAccess.Write)
        Dim writeStream As New StreamWriter(fileStream)

        writeStream.Write(txtUserInput.Text)
        writeStream.Close()

    End Sub
    Private Sub mnuSave_Click(sender As Object, e As EventArgs) Handles mnuSave.Click

        Dim pathOfFile As String = String.Empty ' File path for user created file '
        Dim saveFile As New SaveFileDialog ' Opens save dialog box '
        saveFile.Filter = "Txt files (*.txt)|*.txt"

        ' If dialog box opens, user will continue to save a file '
        If saveFile.ShowDialog() = DialogResult.OK Then

            pathOfFile = saveFile.FileName
            Save(pathOfFile)

        End If

    End Sub

    Private Sub mnuSaveAs_Click(sender As Object, e As EventArgs) Handles mnuSaveAs.Click

        Dim saveFile As New SaveFileDialog ' Opens save dialog box '
        Dim savingFile As String ' Saves file '
        saveFile.Filter = "Txt files (*.txt)|*.txt"

        ' If dialog box opens, user will continue to save a file '
        If saveFile.ShowDialog() = DialogResult.OK Then

            savingFile = saveFile.FileName
            Dim streamWriter As New StreamWriter(savingFile)

            streamWriter.Write(txtUserInput.Text)
            streamWriter.Close()

        End If

    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click

        ' Closes program '
        Me.Close()

    End Sub

    Private Sub mnuCopy_Click(sender As Object, e As EventArgs) Handles mnuCopy.Click

        ' Copies highlighted text '
        If String.IsNullOrEmpty(txtUserInput.Text.ToString()) Then

        Else

            My.Computer.Clipboard.SetText(txtUserInput.SelectedText)

        End If

    End Sub

    Private Sub mnuCut_Click(sender As Object, e As EventArgs) Handles mnuCut.Click

        ' Cuts highlighted text '
        If String.IsNullOrEmpty(txtUserInput.Text.ToString()) Then

        Else

            My.Computer.Clipboard.SetText(txtUserInput.SelectedText)
            txtUserInput.SelectedText = ""

        End If

    End Sub

    Private Sub mnuPaste_Click(sender As Object, e As EventArgs) Handles mnuPaste.Click

        ' Pastes previously copied text '
        txtUserInput.SelectedText() = My.Computer.Clipboard.GetText()

    End Sub

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click

        ' Displays message about the program '
        MessageBox.Show("NETD-2202" & vbCrLf & "Lab# 5" & vbCrLf & "Andrew Rocha")

    End Sub
End Class
